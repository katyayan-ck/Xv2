<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\PerformanceController;
use App\Http\Controllers\ExportController;

Route::get('/', function () {
    return view('welcome');
});
Route::get('/performance-report', [PerformanceController::class, 'report']);
Route::prefix('export')->group(function () {
    Route::get('vehicle-data', [ExportController::class, 'vehicleDataExcel'])
        ->name('export.vehicle.excel');

    Route::get('vehicle-data-csv', [ExportController::class, 'vehicleDataCsv'])
        ->name('export.vehicle.csv');

    Route::get('vehicle-data-simple-csv', [ExportController::class, 'vehicleDataSimpleCsv'])
        ->name('export.vehicle.simple-csv');
});
