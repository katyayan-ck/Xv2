<a href="<?php echo e($link ?? 'javascript:void(0)'); ?>" class="text-decoration-none">
    <div class="card stats-card border-left-<?php echo e($color); ?> shadow-sm h-100">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h6 class="text-muted small text-uppercase mb-1"><?php echo e($title); ?></h6>
                    <div class="stat-value text-<?php echo e($color); ?>"><?php echo e($value); ?></div>
                    <?php if(isset($subtitle)): ?>
                        <p class="text-muted small mb-0"><i class="la la-clock-o"></i> <?php echo e($subtitle); ?></p>
                    <?php endif; ?>
                </div>
                <div class="text-right">
                    <i class="la <?php echo e($icon); ?> text-<?php echo e($color); ?> opacity-5" style="font-size: 2rem;"></i>
                </div>
            </div>
        </div>
    </div>
</a>
<?php /**PATH D:\xampp\htdocs\vdms\resources\views/admin/widgets/stats-card.blade.php ENDPATH**/ ?>