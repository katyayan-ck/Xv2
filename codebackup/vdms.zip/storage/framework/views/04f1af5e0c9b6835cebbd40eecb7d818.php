<div class="card shadow-sm">
    <div class="card-header bg-light">
        <h6 class="mb-0"><i class="la <?php echo e($icon); ?>"></i> <?php echo e($title); ?></h6>
    </div>
    <div class="card-body p-0">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="activity-item px-3">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <?php if($type === 'enquiry'): ?>
                            <strong><?php echo e($item->customer_name ?? 'N/A'); ?></strong>
                            <p class="text-muted small mb-1">
                                <?php echo e(Str::limit($item->message ?? ($item->subject ?? 'No details'), 50)); ?></p>
                        <?php elseif($type === 'booking'): ?>
                            <strong><?php echo e($item->customer_name ?? 'N/A'); ?></strong>
                            <p class="text-muted small mb-1">Vehicle Booking</p>
                        <?php endif; ?>
                        <small class="text-muted"><i class="la la-clock-o"></i>
                            <?php echo e($item->created_at->diffForHumans()); ?></small>
                    </div>
                    <div>
                        <a href="<?php echo e(backpack_url($type . '/' . $item->id . '/show')); ?>" class="btn btn-sm btn-light"
                            title="View">
                            <i class="la la-eye"></i>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="p-3">
                <p class="text-muted small text-center mb-0"><i class="la la-inbox"></i> No recent <?php echo e($title); ?>

                </p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\vdms\resources\views/admin/widgets/activity-feed.blade.php ENDPATH**/ ?>