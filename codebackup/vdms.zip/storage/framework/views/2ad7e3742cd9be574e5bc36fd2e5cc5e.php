<script src="<?php echo e($src); ?>" <?php echo $args; ?>></script>
<?php /**PATH D:\xampp\htdocs\vdms\storage\framework\views/8a07812e6d8f9d2826754abad88e5380.blade.php ENDPATH**/ ?>