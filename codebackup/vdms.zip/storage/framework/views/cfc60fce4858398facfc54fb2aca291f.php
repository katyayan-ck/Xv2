
<script>document.documentElement.setAttribute("data-bs-theme", localStorage.colorMode ?? 'light');</script>

<?php Basset::basset('https://cdn.jsdelivr.net/npm/@tabler/core@1.4.0/dist/css/tabler.min.css', true, ['integrity' => 'sha256-fvdQvRBUamldCxJ2etgEi9jz7F3n2u+xBn+dDao9HJo=', 'crossorigin' => 'anonymous']); ?>
<?php Basset::basset(base_path('vendor/backpack/theme-tabler/resources/assets/css/style.css')); ?>
<?php Basset::basset(base_path('vendor/backpack/theme-tabler/resources/assets/css/color-adjustments.css')); ?>
<?php /**PATH D:\xampp\htdocs\vdms\resources/views/vendor/backpack/theme-tabler/inc/theme_styles.blade.php ENDPATH**/ ?>