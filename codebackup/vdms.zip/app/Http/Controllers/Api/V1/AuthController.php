<?php

namespace App\Http\Controllers\Api\V1;

use App\Services\AuthService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * @OA\Info(
 *      version="1.0.0",
 *      title="Xceler8 API",
 *      description="Vehicle Dealership Management System API",
 *      @OA\Contact(email="support@vdms.com"),
 *      @OA\License(name="Apache 2.0", url="https://www.apache.org/licenses/LICENSE-2.0.html")
 * )
 * @OA\OpenApi(
 *      @OA\Server(url="http://localhost/vdms/public/api/v1", description="Dev"),
 *      @OA\Server(url="https://api.vdms.com/v1", description="Production")
 * )
 * @OA\SecurityScheme(
 *      type="http",
 *      scheme="bearer",
 *      bearerFormat="JWT",
 *      securityScheme="sanctum",
 *      description="Sanctum API Token"
 * )
 */

class AuthController
{
    private AuthService $authService;

    public function __construct(AuthService $authService)
    {
        $this->authService = $authService;
    }

    /**
     * @OA\Post(
     *     path="/api/v1/auth/request-otp",
     *     tags={"Authentication"},
     *     summary="Request OTP for login",
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"mobile"},
     *             @OA\Property(property="mobile", type="string", example="9876543210", description="10-digit mobile number")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="OTP sent successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="http_status", type="integer", example=200),
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="code", type="string", example="S001"),
     *             @OA\Property(property="message", type="string", example="OTP sent to your registered mobile and email"),
     *             @OA\Property(property="data", type="object")
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Mobile not registered",
     *         @OA\JsonContent(
     *             @OA\Property(property="http_status", type="integer", example=404),
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="code", type="string", example="E002"),
     *             @OA\Property(property="message", type="string", example="Mobile not registered")
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Account locked",
     *         @OA\JsonContent(
     *             @OA\Property(property="http_status", type="integer", example=403),
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="code", type="string", example="E004"),
     *             @OA\Property(property="message", type="string", example="Account locked. Contact admin")
     *         )
     *     ),
     *     @OA\Response(
     *         response=429,
     *         description="Rate limit exceeded",
     *         @OA\JsonContent(
     *             @OA\Property(property="http_status", type="integer", example=429),
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="code", type="string", example="E005"),
     *             @OA\Property(property="message", type="string", example="Too many OTP requests. Try again later")
     *         )
     *     )
     * )
     */
    public function requestOtp(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'mobile' => 'required|string|size:10',
        ]);

        $result = $this->authService->requestOtp($validated['mobile']);

        if (!$result['success']) {
            return response()->json([
                'http_status' => $result['error']['http_status'],
                'success' => false,
                'code' => $result['error']['code'],
                'message' => $result['error']['message'],
            ], $result['error']['http_status']);
        }

        return response()->json([
            'http_status' => 200,
            'success' => true,
            'code' => 'S001',
            'message' => 'OTP sent to your registered mobile and email',
            'data' => $result['data'],
        ], 200);
    }

    /**
     * @OA\Post(
     *     path="/api/v1/auth/verify-otp",
     *     tags={"Authentication"},
     *     summary="Verify OTP and bind device for login",
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             required={"mobile","otp","device_id","device_name","platform"},
     *             @OA\Property(property="mobile", type="string", example="9876543210", description="10-digit mobile number"),
     *             @OA\Property(property="otp", type="string", example="123456", description="6-digit OTP"),
     *             @OA\Property(property="device_id", type="string", example="unique-device-uuid", description="Unique device identifier"),
     *             @OA\Property(property="device_name", type="string", example="iPhone 14", description="Device name"),
     *             @OA\Property(property="platform", type="string", example="iOS", description="Device platform (iOS/Android/Web)")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Login successful",
     *         @OA\JsonContent(
     *             @OA\Property(property="http_status", type="integer", example=200),
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="code", type="string", example="S001"),
     *             @OA\Property(property="message", type="string", example="Login successful"),
     *             @OA\Property(property="data", type="object",
     *                 @OA\Property(property="token", type="string", description="API token"),
     *                 @OA\Property(property="user", type="object", description="User details")
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Invalid OTP or expired",
     *         @OA\JsonContent(
     *             @OA\Property(property="http_status", type="integer", example=401),
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="code", type="string", example="E002"),
     *             @OA\Property(property="message", type="string", example="Invalid OTP")
     *         )
     *     ),
     *     @OA\Response(
     *         response=403,
     *         description="Account locked",
     *         @OA\JsonContent(
     *             @OA\Property(property="http_status", type="integer", example=403),
     *             @OA\Property(property="success", type="boolean", example=false),
     *             @OA\Property(property="code", type="string", example="E004"),
     *             @OA\Property(property="message", type="string", example="Account locked due to failed attempts")
     *         )
     *     )
     * )
     */
    public function verifyOtp(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'mobile' => 'required|string|size:10',
            'otp' => 'required|string|size:6',
            'device_id' => 'required|string|unique:device_sessions,device_id',
            'device_name' => 'required|string|max:255',
            'platform' => 'required|string|max:50',
        ]);

        $result = $this->authService->verifyOtp($validated);

        if (!$result['success']) {
            return response()->json([
                'http_status' => $result['error']['http_status'],
                'success' => false,
                'code' => $result['error']['code'],
                'message' => $result['error']['message'],
            ], $result['error']['http_status']);
        }

        return response()->json([
            'http_status' => 200,
            'success' => true,
            'code' => 'S001',
            'message' => 'Login successful',
            'data' => $result['data'],
        ], 200);
    }

    /**
     * @OA\Get(
     *     path="/api/v1/auth/me",
     *     tags={"Authentication"},
     *     summary="Get current user details",
     *     security={{"sanctum":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="User details retrieved",
     *         @OA\JsonContent(
     *             @OA\Property(property="http_status", type="integer", example=200),
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="code", type="string", example="S001"),
     *             @OA\Property(property="data", type="object", description="User object")
     *         )
     *     ),
     *     @OA\Response(response=401, description="Unauthorized")
     * )
     */
    public function me(Request $request): JsonResponse
    {
        $user = $request->user('sanctum');

        $result = $this->authService->me($user);

        if (!$result['success']) {
            return response()->json([
                'http_status' => $result['error']['http_status'],
                'success' => false,
                'code' => $result['error']['code'],
                'message' => $result['error']['message'],
            ], $result['error']['http_status']);
        }

        return response()->json([
            'http_status' => 200,
            'success' => true,
            'code' => 'S001',
            'data' => $result['data'],
        ], 200);
    }

    /**
     * @OA\Post(
     *     path="/api/v1/auth/logout",
     *     tags={"Authentication"},
     *     summary="Logout current session",
     *     security={{"sanctum":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="Logged out",
     *         @OA\JsonContent(
     *             @OA\Property(property="http_status", type="integer", example=200),
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="code", type="string", example="S001"),
     *             @OA\Property(property="message", type="string", example="Logged out successfully")
     *         )
     *     ),
     *     @OA\Response(response=401, description="Unauthorized")
     * )
     */
    public function logout(Request $request): JsonResponse
    {
        $user = $request->user('sanctum');

        $result = $this->authService->logout($user);

        if (!$result['success']) {
            return response()->json([
                'http_status' => $result['error']['http_status'],
                'success' => false,
                'code' => $result['error']['code'],
                'message' => $result['error']['message'],
            ], $result['error']['http_status']);
        }

        return response()->json([
            'http_status' => 200,
            'success' => true,
            'code' => 'S001',
            'message' => 'Logged out successfully',
        ], 200);
    }
}
