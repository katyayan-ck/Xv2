<?php

namespace App\Services;

use App\Models\Core\OtpToken;
use App\Models\Core\DeviceSession;
use App\Models\Core\OtpAttemptLog;
use App\Models\Core\AccountLock;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Cache;
use App\Exceptions\ValidationException;
use App\Exceptions\PermissionException;

class AuthenticationService
{
    const OTP_LENGTH = 6;
    const MAX_OTP_ATTEMPTS = 3;
    const ACCOUNT_LOCK_MINUTES = 30;
    const RATE_LIMIT_WINDOW = 10;
    const RATE_LIMIT_MAX = 3;

    /**
     * Request OTP for login
     */
    public function requestOtp(string $mobile): array
    {
        try {
            $mobile = $this->validateAndFormatMobile($mobile);

            $user = User::where('phone', $mobile)->first(); // Assume 'phone' is mobile field
            if (!$user) {
                return $this->errorResponse('Mobile not registered', 'E002', 404);
            }

            if ($this->isAccountLocked($user)) {
                return $this->errorResponse('Account locked. Contact admin', 'E004', 403);
            }

            if ($this->exceededRateLimit($mobile)) {
                return $this->errorResponse('Too many OTP requests. Try again later', 'E005', 429);
            }

            $otp = $this->generateOtp();
            $expiresAt = now()->addMinutes(10);

            OtpToken::create([
                'user_id' => $user->id,
                'otp_hash' => Hash::make($otp),
                'mobile' => $mobile,
                'expires_at' => $expiresAt,
                'created_by' => $user->id, // Audit
            ]);

            // Log attempt
            OtpAttemptLog::create([
                'user_id' => $user->id,
                'mobile' => $mobile,
                'action' => 'request',
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
                'created_by' => $user->id,
            ]);

            // TODO: Send OTP via SMS/Email (integrate provider)

            return ['success' => true, 'data' => ['otp' => $otp, 'expires_at' => $expiresAt]]; // In prod, don't return OTP
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), 'E500', 500);
        }
    }

    /**
     * Verify OTP and bind device
     */
    public function verifyOtp(array $data): array
    {
        try {
            $mobile = $this->validateAndFormatMobile($data['mobile']);

            $user = User::where('phone', $mobile)->first();
            if (!$user) {
                return $this->errorResponse('Mobile not registered', 'E002', 404);
            }

            $otpToken = OtpToken::where('user_id', $user->id)->where('mobile', $mobile)->latest()->first();
            if (!$otpToken || $otpToken->expires_at < now()) {
                return $this->errorResponse('OTP expired or invalid', 'E002', 401);
            }

            if (!Hash::check($data['otp'], $otpToken->otp_hash)) {
                $this->logFailedAttempt($user, $mobile, 'Invalid OTP');
                if ($this->failedAttemptsExceeded($mobile)) {
                    $this->lockAccount($user, 'Too many failed attempts');
                    return $this->errorResponse('Account locked due to failed attempts', 'E004', 403);
                }
                return $this->errorResponse('Invalid OTP', 'E002', 401);
            }

            // Bind device
            DeviceSession::create([
                'user_id' => $user->id,
                'device_id' => $data['device_id'],
                'device_name' => $data['device_name'],
                'platform' => $data['platform'],
                'last_active_at' => now(),
                'created_by' => $user->id,
            ]);

            // Create Sanctum token with device ability
            $token = $user->createToken('api-token', ['device_id' => $data['device_id']]);

            // Log success
            OtpAttemptLog::create([
                'user_id' => $user->id,
                'mobile' => $mobile,
                'action' => 'verify',
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
                'created_by' => $user->id,
            ]);

            // Delete used OTP
            $otpToken->delete();

            return ['success' => true, 'data' => ['token' => $token->plainTextToken, 'user' => $user]];
        } catch (\Exception $e) {
            return $this->errorResponse($e->getMessage(), 'E500', 500);
        }
    }

    /**
     * Get current user info
     */
    public function me(User $user): array
    {
        return ['success' => true, 'data' => $user];
    }

    /**
     * Logout and revoke token
     */
    public function logout(User $user): array
    {
        $user->currentAccessToken()->delete();
        return ['success' => true];
    }

    // Helper methods (adapt from reference)
    private function validateAndFormatMobile(string $mobile): string
    {
        if (!preg_match('/^\d{10}$/', $mobile)) {
            throw new ValidationException('Invalid mobile number format');
        }
        return $mobile;
    }

    private function generateOtp(): string
    {
        return str_pad(rand(0, 999999), self::OTP_LENGTH, '0', STR_PAD_LEFT);
    }

    private function isAccountLocked(User $user): bool
    {
        $lock = AccountLock::where('user_id', $user->id)->where('locked_until', '>', now())->first();
        return (bool) $lock;
    }

    private function exceededRateLimit(string $mobile): bool
    {
        $key = 'otp_rate:' . $mobile;
        $attempts = Cache::get($key, 0);
        if ($attempts >= self::RATE_LIMIT_MAX) {
            return true;
        }
        Cache::put($key, $attempts + 1, self::RATE_LIMIT_WINDOW * 60);
        return false;
    }

    private function logFailedAttempt(User $user, string $mobile, string $reason): void
    {
        OtpAttemptLog::create([
            'user_id' => $user->id,
            'mobile' => $mobile,
            'action' => 'verify_failed',
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'reason' => $reason,
            'created_by' => $user->id,
        ]);
    }

    private function failedAttemptsExceeded(string $mobile): bool
    {
        $count = OtpAttemptLog::where('mobile', $mobile)
            ->where('action', 'verify_failed')
            ->where('created_at', '>', now()->subMinutes(15))
            ->count();
        return $count >= self::MAX_OTP_ATTEMPTS;
    }

    private function lockAccount(User $user, string $reason): void
    {
        AccountLock::create([
            'user_id' => $user->id,
            'locked_until' => now()->addMinutes(self::ACCOUNT_LOCK_MINUTES),
            'reason' => $reason,
            'created_by' => $user->id,
        ]);
    }

    private function errorResponse(string $message, string $code, int $status): array
    {
        return ['success' => false, 'error' => ['message' => $message, 'code' => $code, 'http_status' => $status]];
    }
}
