<button class="navbar-toggler collapsed p-0" type="button" data-bs-toggle="collapse" data-bs-target="#mobile-menu" aria-controls="mobile-menu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
</button><?php /**PATH D:\xampp\htdocs\vdms\resources/views/vendor/backpack/theme-tabler/layouts/partials/mobile_toggle_btn.blade.php ENDPATH**/ ?>