<?php

namespace App\Http\Controllers\Admin;

use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Http\Requests\CrudRequest;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use \Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use \Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
use \Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use \Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;

class ApprovalHierarchyCrudController extends CrudController
{
    use ListOperation;
    use CreateOperation;
    use UpdateOperation;
    use DeleteOperation;

    public function setup()
    {
        CRUD::setModel(\App\Models\Core\ApprovalHierarchy::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/approval-hierarchy');
        CRUD::setEntityNameStrings('approval hierarchy', 'approval hierarchies');
    }

    protected function setupListOperation()
    {
        //if (!backpack_user()->can('approval_hierarchy.view')) abort(403);
        CRUD::column('approver.name')->label('Approver');
        CRUD::column('level');
        CRUD::column('topic');
        CRUD::column('combo_json')->type('json');
        CRUD::column('powers_json')->type('json');
        CRUD::column('is_active')->type('boolean');
    }

    protected function setupCreateOperation()
    {
        //if (!backpack_user()->can('approval_hierarchy.create')) abort(403);
        CRUD::field('approver_id')->type('select2')->entity('approver')->attribute('name');
        CRUD::field('level')->type('number')->min(1)->max(5);
        CRUD::field('topic')->hint('e.g. quotation');
        CRUD::field('combo_json')->type('json')->hint('Combo filters');
        CRUD::field('powers_json')->type('json')->hint('e.g. {"discount_max": 5000}');
        CRUD::field('is_active')->type('boolean');
    }

    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }
}
