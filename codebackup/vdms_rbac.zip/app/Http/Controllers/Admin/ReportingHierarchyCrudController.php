<?php

namespace App\Http\Controllers\Admin;

use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use \Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use \Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
use \Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use \Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;

class ReportingHierarchyCrudController extends CrudController
{
    use ListOperation;
    use CreateOperation;
    use UpdateOperation;
    use DeleteOperation;

    public function setup()
    {
        CRUD::setModel(\App\Models\Core\ReportingHierarchy::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/reporting-hierarchy');
        CRUD::setEntityNameStrings('reporting hierarchy', 'reporting hierarchies');
    }

    protected function setupListOperation()
    {
        //if (!backpack_user()->can('reporting_hierarchy.view')) abort(403);
        CRUD::column('user.name')->label('User');
        CRUD::column('supervisor.name')->label('Supervisor');
        CRUD::column('topic');
        CRUD::column('is_active')->type('boolean');
    }

    protected function setupCreateOperation()
    {
        //if (!backpack_user()->can('reporting_hierarchy.create')) abort(403);
        CRUD::field('user_id')->type('select2')->entity('user')->attribute('name');
        CRUD::field('supervisor_id')->type('select2')->entity('supervisor')->attribute('name');
        CRUD::field('topic')->hint('e.g., sales, operations');
        CRUD::field('combo_json')->type('json')->hint('Optional filters');
        CRUD::field('is_active')->type('boolean')->default(true);
    }

    protected function setupUpdateOperation()
    {
        //if (!backpack_user()->can('reporting_hierarchy.edit')) abort(403);
        $this->setupCreateOperation();
    }
}
