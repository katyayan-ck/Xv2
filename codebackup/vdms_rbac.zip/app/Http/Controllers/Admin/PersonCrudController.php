<?php

namespace App\Http\Controllers\Admin;

use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use \Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
use \Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
use \Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
use \Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;

class PersonCrudController extends CrudController
{
    use ListOperation;
    use CreateOperation;
    use UpdateOperation;
    use DeleteOperation;

    public function setup()
    {
        CRUD::setModel(\App\Models\Core\Person::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/person');
        CRUD::setEntityNameStrings('person', 'persons');
    }

    protected function setupListOperation()
    {
        //if (!backpack_user()->can('person.view')) abort(403);
        CRUD::column('code');
        CRUD::column('first_name');
        CRUD::column('last_name');
        CRUD::column('email');
        CRUD::column('phone');
        CRUD::column('date_of_birth');
        CRUD::column('gender');
        CRUD::column('is_active')->type('boolean');
    }

    protected function setupCreateOperation()
    {
        //if (!backpack_user()->can('person.create')) abort(403);
        CRUD::field('code');
        CRUD::field('first_name')->required();
        CRUD::field('middle_name');
        CRUD::field('last_name')->required();
        CRUD::field('email');
        CRUD::field('phone');
        CRUD::field('date_of_birth')->type('date');
        CRUD::field('gender')->type('select_from_array')->options(['male' => 'Male', 'female' => 'Female', 'other' => 'Other']);
        CRUD::field('identification_type')->type('select_from_array')->options(['pan' => 'PAN', 'aadhar' => 'Aadhaar', 'passport' => 'Passport']);
        CRUD::field('identification_number');
        CRUD::field('is_active')->type('boolean')->default(true);
    }

    protected function setupUpdateOperation()
    {
        //if (!backpack_user()->can('person.edit')) abort(403);
        $this->setupCreateOperation();
    }
}
