<?php

namespace App\Models\Traits;

use App\Models\UserDataScope;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Scope;

/**
 * Global Scope for filtering by user data scope
 * 
 * Apply this to models that need data scoping:
 * - Branch, Location, Department, Vertical, Segment, Brand
 * 
 * Usage in Model:
 * class Branch extends Model {
 *     use FilterByDataScope;
 *     
 *     protected static function booted()
 *     {
 *         static::addGlobalScope(new FilterByDataScope());
 *     }
 * }
 */
class FilterByDataScope implements Scope
{
    /**
     * Apply the scope to a given Eloquent query builder.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $builder
     * @param  \Illuminate\Database\Eloquent\Model  $model
     * @return void
     */
    public function apply(Builder $builder, $model)
    {
        $user = auth()->user();

        // ✅ CRITICAL: SuperAdmin gets complete bypass
        if ($user && $user->isSuperAdmin()) {
            return;  // Don't apply any filters - return early!
        }

        if (!$user) {
            $builder->whereRaw('0 = 1');
            return;
        }

        // Get scope type for this model
        $scopeType = $this->getScopeType($model);

        if (!$scopeType) {
            return; // Model doesn't have scoping
        }

        // Get user's scopes for this entity type
        $scopes = $user->userDataScopes()
            ->byType($scopeType)
            ->active()
            ->get();

        // No scopes assigned - deny all access
        if ($scopes->isEmpty()) {
            $builder->whereRaw('1 = 0');
            return;
        }

        // Check for wildcard (NULL = all instances)
        $hasWildcard = $scopes->contains(fn($scope) => $scope->isWildcard());

        if ($hasWildcard) {
            // User has access to all instances
            return;
        }

        // User has access to specific instances
        $accessibleIds = $scopes->pluck('scope_value')->filter()->values();

        $builder->whereIn('id', $accessibleIds);
    }

    /**
     * Get the scope type for a model
     *
     * @param  \Illuminate\Database\Eloquent\Model  $model
     * @return string|null
     */
    private function getScopeType($model): ?string
    {
        // Check if model has explicit scope type
        if (property_exists($model, 'scopeType')) {
            return $model->scopeType;
        } else
            return null;

        $class = get_class($model);

        return match ($class) {
            \App\Models\Branch::class => 'branch',
            \App\Models\Location::class => 'location',
            \App\Models\Department::class => 'department',
            \App\Models\Vertical::class => 'vertical',
            \App\Models\Segment::class => 'segment',
            \App\Models\Brand::class => 'brand',
            default => null,
        };
    }
}
