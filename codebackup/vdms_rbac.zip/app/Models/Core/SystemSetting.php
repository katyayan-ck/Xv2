<?php

namespace App\Models\Core;

use App\Models\BaseModel;
use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Facades\Cache;

/**
 * SystemSetting Model
 * 
 * Stores application configuration settings
 * Cached for performance optimization
 */
class SystemSetting extends BaseModel
{
    use CrudTrait;
    use HasFactory;
    protected $table = 'system_settings';

    protected $fillable = [
        'key',
        'value',
        'type',
        'description',
        'is_editable',
    ];

    protected $casts = [
        'is_editable' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Boot: Clear cache when setting is updated
     */
    public static function boot()
    {
        parent::boot();

        static::saved(function ($model) {
            Cache::forget("setting.{$model->key}");
        });

        static::deleted(function ($model) {
            Cache::forget("setting.{$model->key}");
        });
    }

    /**
     * Get setting value with type casting
     */
    public static function getValue($key, $default = null)
    {
        $setting = Cache::rememberForever("setting.{$key}", function () use ($key) {
            return self::where('key', $key)->first();
        });

        if (!$setting) {
            return $default;
        }

        return match ($setting->type) {
            'boolean' => filter_var($setting->value, FILTER_VALIDATE_BOOLEAN),
            'integer' => (int) $setting->value,
            'float' => (float) $setting->value,
            'array' => json_decode($setting->value, true) ?? [],
            'json' => json_decode($setting->value, true) ?? [],
            default => $setting->value,
        };
    }

    /**
     * Scope: Get only editable settings
     */
    public function scopeEditable($query)
    {
        return $query->where('is_editable', true);
    }

    /**
     * Scope: Get settings by type
     */
    public function scopeByType($query, $type)
    {
        return $query->where('type', $type);
    }
}
