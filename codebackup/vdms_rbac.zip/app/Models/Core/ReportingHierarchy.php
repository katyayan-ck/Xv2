<?php

namespace App\Models\Core;

use App\Models\BaseModel;
use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\User; 

class ReportingHierarchy extends BaseModel
{
    use CrudTrait;
    use HasFactory;
    protected $fillable = [
        'user_id',
        'supervisor_id',
        'topic',
        'combo_json',
        'is_active'
    ];

    protected $casts = [
        'combo_json' => 'array',
        'is_active' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function supervisor()
    {
        return $this->belongsTo(User::class, 'supervisor_id');
    }
}
