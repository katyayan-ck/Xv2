<?php

namespace App\Models\Core;

use App\Models\BaseModel;
use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\User; 

class ApprovalHierarchy extends BaseModel
{
    use CrudTrait;
    use HasFactory;
    protected $fillable = [
        'approver_id',
        'level',
        'topic',
        'combo_json',
        'powers_json',
        'is_active'
    ];

    protected $casts = [
        'combo_json' => 'array',
        'powers_json' => 'array',
        'level' => 'integer',
        'is_active' => 'boolean',
    ];

    public function approver()
    {
        return $this->belongsTo(User::class, 'approver_id');
    }
}
