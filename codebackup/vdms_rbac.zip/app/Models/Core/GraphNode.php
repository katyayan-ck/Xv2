<?php

namespace App\Models\Core;

use App\Models\BaseModel;
use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\User; 

class GraphNode extends BaseModel
{
    use CrudTrait;
    use HasFactory;
    protected $fillable = ['user_id', 'role', 'attributes'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function outgoingEdges()
    {
        return $this->hasMany(GraphEdge::class, 'from_node_id');
    }
    public function incomingEdges()
    {
        return $this->hasMany(GraphEdge::class, 'to_node_id');
    }
}
