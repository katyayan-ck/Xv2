<?php

namespace App\Models\Scopes;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Scope;

class UserDataScope implements Scope
{
    /**
     * Global Scope with hierarchical null-as-wildcard logic
     * 
     * Hierarchy:
     * Branch (0) → Location (1) → Department (2) → Division (3) → Vertical (4)
     * Brand (0) → Segment (1) → SubSegment (2) → VehicleModel (3) → Variant (4) → Color (5)
     */
    public function apply(Builder $query, Model $model): void
    {
        $user = backpack_auth()->user();

        // Skip for SuperAdmin
        if ($user && $user->isSuperAdmin()) {
            return;
        }

        if (!$user) {
            $query->whereRaw('0 = 1');
            return;
        }

        $modelClass = class_basename($model);

        // Apply hierarchical filtering based on model type
        match ($modelClass) {
            'Branch' => $this->filterByBranch($query, $user),
            'Location' => $this->filterByLocation($query, $user),
            'Department' => $this->filterByDepartment($query, $user),
            'Division' => $this->filterByDivision($query, $user),
            'Vertical' => $this->filterByVertical($query, $user),
            'Brand' => $this->filterByBrand($query, $user),
            'Segment' => $this->filterBySegment($query, $user),
            'SubSegment' => $this->filterBySubSegment($query, $user),
            'VehicleModel' => $this->filterByVehicleModel($query, $user),
            'Variant' => $this->filterByVariant($query, $user),
            'Color' => $this->filterByColor($query, $user),
            'Employee' => $this->filterByEmployee($query, $user),
            'ApprovalHierarchy' => $this->filterByApprovalHierarchy($query, $user),
            default => null,
        };
    }

    /**
     * Filter by Branch
     * Logic: If user has branch scope, show only those branches
     *        If user has null for branch scope, show all branches
     */
    private function filterByBranch(Builder $query, $user): void
    {
        $branches = $user->getAccessibleBranches();

        if ($branches === []) {
            // No branch access
            $query->whereRaw('0 = 1');
            return;
        }

        if ($branches !== null) {
            // Specific branches only
            $query->whereIn('id', $branches);
        }
        // else: null = all branches, no filter
    }

    /**
     * Filter by Location
     * Hierarchy: User might be restricted by both Branch AND Location
     * 
     * Scenarios:
     * 1. User assigned Branch X + Location Y
     *    → Show only Location Y of Branch X
     * 2. User assigned Branch X + Location null
     *    → Show all Locations of Branch X
     * 3. User assigned Location Y only (Branch null)
     *    → Show Location Y across all branches
     */
    private function filterByLocation(Builder $query, $user): void
    {
        $locations = $user->getAccessibleLocations();
        $branches = $user->getAccessibleBranches();

        // No access
        if ($locations === []) {
            $query->whereRaw('0 = 1');
            return;
        }

        // Build query based on hierarchy
        if ($locations !== null) {
            // User has specific locations
            $query->whereIn('id', $locations);
        }

        // If locations is null, but branches are restricted, filter by branch
        if ($locations === null && $branches !== null && $branches !== []) {
            $query->whereIn('branch_id', $branches);
        }
        // else: completely unrestricted at this level
    }

    /**
     * Filter by Department
     * Hierarchy: Department (optional parent: Division)
     */
    private function filterByDepartment(Builder $query, $user): void
    {
        $departments = $user->getAccessibleDepartments();
        $divisions = $user->getAccessibleDivisions();

        if ($departments === []) {
            $query->whereRaw('0 = 1');
            return;
        }

        if ($departments !== null) {
            $query->whereIn('id', $departments);
        } elseif ($divisions !== null && $divisions !== []) {
            // If department is wildcard but division is restricted, filter by division
            $query->whereIn('division_id', $divisions);
        }
    }

    /**
     * Filter by Division
     */
    private function filterByDivision(Builder $query, $user): void
    {
        $divisions = $user->getAccessibleDivisions();
        $departments = $user->getAccessibleDepartments();

        if ($divisions === []) {
            $query->whereRaw('0 = 1');
            return;
        }

        if ($divisions !== null) {
            $query->whereIn('id', $divisions);
        }
    }

    /**
     * Filter by Vertical
     */
    private function filterByVertical(Builder $query, $user): void
    {
        $verticals = $user->getAccessibleVerticals();

        if ($verticals === []) {
            $query->whereRaw('0 = 1');
            return;
        }

        if ($verticals !== null) {
            $query->whereIn('id', $verticals);
        }
    }

    /**
     * Filter by Brand
     * Hierarchy: Brand → Segment → SubSegment → VehicleModel
     */
    private function filterByBrand(Builder $query, $user): void
    {
        $brands = $user->getAccessibleBrands();
        $segments = $user->getAccessibleSegments();

        if ($brands === []) {
            $query->whereRaw('0 = 1');
            return;
        }

        if ($brands !== null) {
            $query->whereIn('id', $brands);
        } elseif ($segments !== null && $segments !== []) {
            // If brand is wildcard but segment is restricted, get brands of those segments
            $query->whereIn('id', function ($subQuery) use ($segments) {
                $subQuery->select('brand_id')
                    ->from('segments')
                    ->whereIn('id', $segments);
            });
        }
    }

    /**
     * Filter by Segment
     * Hierarchy: Brand → Segment → SubSegment → VehicleModel
     */
    private function filterBySegment(Builder $query, $user): void
    {
        $segments = $user->getAccessibleSegments();
        $brands = $user->getAccessibleBrands();
        $subSegments = $user->getAccessibleSubSegments();

        if ($segments === []) {
            $query->whereRaw('0 = 1');
            return;
        }

        if ($segments !== null) {
            $query->whereIn('id', $segments);
        } elseif ($brands !== null && $brands !== []) {
            // If segment is wildcard but brand is restricted
            $query->whereIn('brand_id', $brands);
        } elseif ($subSegments !== null && $subSegments !== []) {
            // If segment is wildcard but sub_segment is restricted, get segments of those sub-segments
            $query->whereIn('id', function ($subQuery) use ($subSegments) {
                $subQuery->select('segment_id')
                    ->from('sub_segments')
                    ->whereIn('id', $subSegments);
            });
        }
    }

    /**
     * Filter by SubSegment
     */
    private function filterBySubSegment(Builder $query, $user): void
    {
        $subSegments = $user->getAccessibleSubSegments();
        $segments = $user->getAccessibleSegments();
        $brands = $user->getAccessibleBrands();

        if ($subSegments === []) {
            $query->whereRaw('0 = 1');
            return;
        }

        if ($subSegments !== null) {
            $query->whereIn('id', $subSegments);
        } elseif ($segments !== null && $segments !== []) {
            $query->whereIn('segment_id', $segments);
        } elseif ($brands !== null && $brands !== []) {
            // Get sub-segments of segments of brands
            $query->whereIn('segment_id', function ($subQuery) use ($brands) {
                $subQuery->select('id')
                    ->from('segments')
                    ->whereIn('brand_id', $brands);
            });
        }
    }

    /**
     * Filter by VehicleModel
     * Hierarchy: Brand → Segment → SubSegment → VehicleModel
     */
    private function filterByVehicleModel(Builder $query, $user): void
    {
        $models = $user->getAccessibleVehicleModels();
        $subSegments = $user->getAccessibleSubSegments();
        $segments = $user->getAccessibleSegments();
        $brands = $user->getAccessibleBrands();

        if ($models === []) {
            $query->whereRaw('0 = 1');
            return;
        }

        if ($models !== null) {
            $query->whereIn('id', $models);
        } elseif ($subSegments !== null && $subSegments !== []) {
            $query->whereIn('sub_segment_id', $subSegments);
        } elseif ($segments !== null && $segments !== []) {
            $query->whereIn('sub_segment_id', function ($subQuery) use ($segments) {
                $subQuery->select('id')
                    ->from('sub_segments')
                    ->whereIn('segment_id', $segments);
            });
        } elseif ($brands !== null && $brands !== []) {
            // Deeply nested query
            $query->whereIn('sub_segment_id', function ($subQuery1) use ($brands) {
                $subQuery1->select('id')
                    ->from('sub_segments')
                    ->whereIn('segment_id', function ($subQuery2) use ($brands) {
                        $subQuery2->select('id')
                            ->from('segments')
                            ->whereIn('brand_id', $brands);
                    });
            });
        }
    }

    /**
     * Filter by Variant
     * Hierarchy: Brand → Segment → SubSegment → VehicleModel → Variant
     */
    private function filterByVariant(Builder $query, $user): void
    {
        $variants = $user->getAccessibleVariants();
        $models = $user->getAccessibleVehicleModels();
        $subSegments = $user->getAccessibleSubSegments();

        if ($variants === []) {
            $query->whereRaw('0 = 1');
            return;
        }

        if ($variants !== null) {
            $query->whereIn('id', $variants);
        } elseif ($models !== null && $models !== []) {
            $query->whereIn('vehicle_model_id', $models);
        } elseif ($subSegments !== null && $subSegments !== []) {
            $query->whereIn('vehicle_model_id', function ($subQuery) use ($subSegments) {
                $subQuery->select('id')
                    ->from('vehicle_models')
                    ->whereIn('sub_segment_id', $subSegments);
            });
        }
        // ... continue hierarchy if needed
    }

    /**
     * Filter by Color
     * Colors are typically global unless specifically scoped
     */
    private function filterByColor(Builder $query, $user): void
    {
        // Colors usually not scoped
        // But if you want to scope them:
        // $colors = $user->getAccessibleColors();
        // if ($colors !== null) {
        //     $query->whereIn('id', $colors);
        // }
    }

    /**
     * Filter Employee by their assignments
     */
    private function filterByEmployee(Builder $query, $user): void
    {
        $branches = $user->getAccessibleBranches();
        $locations = $user->getAccessibleLocations();
        $departments = $user->getAccessibleDepartments();
        $divisions = $user->getAccessibleDivisions();
        $verticals = $user->getAccessibleVerticals();

        $hasRestrictions = ($branches !== null) || ($locations !== null) ||
            ($departments !== null) || ($divisions !== null) ||
            ($verticals !== null);

        if (!$hasRestrictions) {
            return;  // No restrictions, show all employees
        }

        // Apply restrictions based on employee assignments
        if ($branches !== null && !empty($branches)) {
            $query->whereHas('branchAssignments', function ($q) use ($branches) {
                $q->whereIn('branch_id', $branches);
            });
        }

        if ($locations !== null && !empty($locations)) {
            $query->whereHas('locationAssignments', function ($q) use ($locations) {
                $q->whereIn('location_id', $locations);
            });
        }

        if ($departments !== null && !empty($departments)) {
            $query->whereHas('departmentAssignments', function ($q) use ($departments) {
                $q->whereIn('department_id', $departments);
            });
        }

        // ... add more as needed
    }

    /**
     * Filter ApprovalHierarchy
     */
    private function filterByApprovalHierarchy(Builder $query, $user): void
    {
        $branches = $user->getAccessibleBranches();

        if ($branches === []) {
            $query->whereRaw('0 = 1');
            return;
        }

        if ($branches !== null) {
            $query->whereIn('branch_id', $branches);
        }
    }
}
