<?php

// database/seeders/SystemSettingSeeder.php

namespace Database\Seeders;

use App\Models\Core\SystemSetting;
use Illuminate\Database\Seeder;

class SystemSettingSeeder extends Seeder
{
    public function run(): void
    {
        // Site Settings
        SystemSetting::ensure(
            'site.name',
            'My Dealership CRM',
            'site',
            'string',
            'Site Name',
            'Name of your website'
        )->update([
            'group' => 'Basic Settings',
            'input_type' => 'text',
            'validation_rules' => 'required|string|max:255',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'site.url',
            'https://crm.example.com',
            'site',
            'string',
            'Site URL',
            'Main URL of your website'
        )->update([
            'group' => 'Basic Settings',
            'input_type' => 'url',
            'validation_rules' => 'required|url',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'site.slogan',
            'Drive Your Success',
            'site',
            'string',
            'Site Slogan',
            'Tagline or slogan'
        )->update([
            'group' => 'Basic Settings',
            'input_type' => 'text',
            'validation_rules' => 'string|max:255',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'site.logo.header',
            '/images/logo-header.png',
            'site',
            'image',
            'Header Logo',
            'Logo displayed in header'
        )->update([
            'group' => 'Logo Settings',
            'input_type' => 'image',
            'help_text' => 'Upload a logo for the header',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'site.logo.footer',
            '/images/logo-footer.png',
            'site',
            'image',
            'Footer Logo',
            'Logo displayed in footer'
        )->update([
            'group' => 'Logo Settings',
            'input_type' => 'image',
            'help_text' => 'Upload a logo for the footer',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'site.logo.login',
            '/images/logo-login.png',
            'site',
            'image',
            'Login Page Logo',
            'Logo displayed on login page'
        )->update([
            'group' => 'Logo Settings',
            'input_type' => 'image',
            'help_text' => 'Upload a logo for the login page',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'site.logo.favicon',
            '/favicon.ico',
            'site',
            'image',
            'Favicon',
            'Browser tab icon'
        )->update([
            'group' => 'Logo Settings',
            'input_type' => 'image',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'site.footer.text',
            '&copy; ' . date('Y') . ' All rights reserved.',
            'site',
            'string',
            'Footer Text',
            'Text displayed in footer'
        )->update([
            'group' => 'Footer Settings',
            'input_type' => 'textarea',
            'help_text' => 'HTML is allowed',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'site.theme',
            'light',
            'site',
            'string',
            'Theme',
            'Light or dark theme'
        )->update([
            'group' => 'Appearance',
            'input_type' => 'select',
            'options' => json_encode(['light' => 'Light', 'dark' => 'Dark']),
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'site.skin',
            'blue',
            'site',
            'string',
            'Skin/Color Scheme',
            'Color scheme of the application'
        )->update([
            'group' => 'Appearance',
            'input_type' => 'select',
            'options' => json_encode([
                'blue' => 'Blue',
                'green' => 'Green',
                'red' => 'Red',
                'purple' => 'Purple',
                'orange' => 'Orange',
            ]),
            'is_visible' => true,
        ]);

        // Dealership Settings
        SystemSetting::ensure(
            'dealership.name',
            'ABC Motors Pvt. Ltd.',
            'dealership',
            'string',
            'Dealership Name',
            'Name of your dealership'
        )->update([
            'group' => 'Basic Information',
            'input_type' => 'text',
            'validation_rules' => 'required|string|max:255',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'dealership.address',
            '123 Main Street, City, State 12345',
            'dealership',
            'string',
            'Address',
            'Business address'
        )->update([
            'group' => 'Contact Details',
            'input_type' => 'textarea',
            'validation_rules' => 'required|string|max:500',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'dealership.phone',
            '+91-8800000000',
            'dealership',
            'string',
            'Phone Number',
            'Main phone number'
        )->update([
            'group' => 'Contact Details',
            'input_type' => 'text',
            'validation_rules' => 'required|string|max:20',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'dealership.email',
            'info@abcmotors.com',
            'dealership',
            'string',
            'Email Address',
            'Main email address'
        )->update([
            'group' => 'Contact Details',
            'input_type' => 'email',
            'validation_rules' => 'required|email|max:255',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'dealership.website',
            'https://www.abcmotors.com',
            'dealership',
            'string',
            'Website URL',
            'Business website'
        )->update([
            'group' => 'Contact Details',
            'input_type' => 'url',
            'validation_rules' => 'url|max:255',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'dealership.pan',
            'AABCU1234A',
            'dealership',
            'string',
            'PAN',
            'Permanent Account Number'
        )->update([
            'group' => 'Legal Information',
            'input_type' => 'text',
            'validation_rules' => 'string|max:10',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'dealership.gstin',
            '27AABCU1234A1Z0',
            'dealership',
            'string',
            'GSTIN',
            'GST Identification Number'
        )->update([
            'group' => 'Legal Information',
            'input_type' => 'text',
            'validation_rules' => 'string|max:15',
            'is_visible' => true,
        ]);

        // Pricing Settings
        SystemSetting::ensure(
            'pricing.gst_rate',
            '18',
            'pricing',
            'integer',
            'GST Rate (%)',
            'Goods and Services Tax rate'
        )->update([
            'group' => 'Tax Rates',
            'input_type' => 'number',
            'validation_rules' => 'required|integer|min:0|max:100',
            'help_text' => 'Enter as percentage (e.g., 18 for 18%)',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'pricing.tds_rate',
            '1',
            'pricing',
            'integer',
            'TDS Rate (%)',
            'Tax Deducted at Source rate'
        )->update([
            'group' => 'Tax Rates',
            'input_type' => 'number',
            'validation_rules' => 'required|integer|min:0|max:100',
            'help_text' => 'Enter as percentage (e.g., 1 for 1%)',
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'pricing.currency',
            'INR',
            'pricing',
            'string',
            'Currency',
            'Default currency'
        )->update([
            'group' => 'Currency',
            'input_type' => 'select',
            'options' => json_encode(['INR' => 'Indian Rupee (₹)', 'USD' => 'US Dollar ($)', 'EUR' => 'Euro (€)']),
            'is_visible' => true,
        ]);

        SystemSetting::ensure(
            'pricing.currency_symbol',
            '₹',
            'pricing',
            'string',
            'Currency Symbol',
            'Symbol to display for currency'
        )->update([
            'group' => 'Currency',
            'input_type' => 'text',
            'is_visible' => true,
        ]);
    }
}


// Add to database/seeders/DatabaseSeeder.php:
// $this->call(SystemSettingSeeder::class);