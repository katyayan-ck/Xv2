<?php

namespace App\Models\Core;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Cache;
use App\Models\BaseModel;

/**
 * SystemSetting Model
 * 
 * Manages application-wide configuration settings with:
 * - Topic/Category based organization
 * - Type casting and validation
 * - Media attachment support (via spatie media library)
 * - Audit trail
 * - Redis caching
 * - File handling (logos, downloads)
 */
class SystemSetting extends BaseModel
{
    use CrudTrait, HasFactory, SoftDeletes;

    protected $table = 'systemsettings';

    protected $fillable = [
        'key',
        'label',
        'value',
        'default_value',
        'type',
        'input_type',
        'topic',
        'group',
        'sort_order',
        'description',
        'help_text',
        'validation_rules',
        'options',
        'iseditable',
        'is_visible',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'iseditable' => 'boolean',
        'is_visible' => 'boolean',
        'options' => 'json',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    protected static function boot()
    {
        parent::boot();

        // Clear cache when setting is created/updated/deleted
        static::saved(function (self $model) {
            static::flushCache($model->key);
            static::flushTopicCache($model->topic);
        });

        static::deleted(function (self $model) {
            static::flushCache($model->key);
            static::flushTopicCache($model->topic);
        });

        // Audit trail
        static::saved(function (self $model) {
            if ($model->wasChanged()) {
                SystemSettingAudit::create([
                    'setting_id' => $model->id,
                    'user_id' => auth()->id(),
                    'action' => $model->wasRecentlyCreated ? 'created' : 'updated',
                    'old_value' => json_encode($model->getOriginal()),
                    'new_value' => json_encode($model->getChanges()),
                    'ip_address' => request()->ip(),
                    'user_agent' => request()->userAgent(),
                ]);
            }
        });

        static::deleted(function (self $model) {
            SystemSettingAudit::create([
                'setting_id' => $model->id,
                'user_id' => auth()->id(),
                'action' => 'deleted',
                'old_value' => json_encode($model->toArray()),
                'new_value' => null,
                'ip_address' => request()->ip(),
                'user_agent' => request()->userAgent(),
            ]);
        });
    }

    // /**
    //  * Relationship: Audit trail
    //  */
    // public function audits(): HasMany
    // {
    //     return $this->hasMany(SystemSettingAudit::class, 'setting_id');
    // }

    // /**
    //  * Get a setting value with type casting
    //  * 
    //  * @param string $key Setting key (e.g., 'site.name')
    //  * @param mixed $default Default value if not found
    //  * @return mixed
    //  */
    // public static function get(string $key, mixed $default = null): mixed
    // {
    //     return static::getValue($key, $default);
    // }

    // /**
    //  * Get value with caching and type casting
    //  */
    // public static function getValue(string $key, mixed $default = null): mixed
    // {
    //     $cacheKey = "setting.{$key}";

    //     $setting = Cache::rememberForever($cacheKey, function () use ($key) {
    //         return self::where('key', $key)->first();
    //     });

    //     if (!$setting) {
    //         return $default;
    //     }

    //     return self::castValue($setting);
    // }

    // /**
    //  * Cast setting value based on type
    //  */
    // protected static function castValue(self $setting): mixed
    // {
    //     return match ($setting->type) {
    //         'boolean' => filter_var($setting->value, FILTER_VALIDATE_BOOLEAN),
    //         'integer' => (int) $setting->value,
    //         'float' => (float) $setting->value,
    //         'array' => json_decode($setting->value, true) ?? [],
    //         'json' => json_decode($setting->value, true) ?? [],
    //         'file', 'image' => $setting->value, // Return path/url
    //         default => $setting->value,
    //     };
    // }

    // /**
    //  * Get all settings as key-value array
    //  */
    // public static function getAllAsArray(): array
    // {
    //     return self::whereIsVisible(true)
    //         ->get()
    //         ->mapWithKeys(fn($row) => [$row->key => self::castValue($row)])
    //         ->toArray();
    // }

    // /**
    //  * Get settings by topic
    //  */
    // public static function getByTopic(string $topic): array
    // {
    //     $cacheKey = "topic.{$topic}";

    //     return Cache::rememberForever($cacheKey, function () use ($topic) {
    //         return self::where('topic', $topic)
    //             ->where('is_visible', true)
    //             ->orderBy('group')
    //             ->orderBy('sort_order')
    //             ->orderBy('key')
    //             ->get()
    //             ->groupBy('group')
    //             ->map(fn($group) => $group->mapWithKeys(
    //                 fn($row) => [$row->key => self::castValue($row)]
    //             ))
    //             ->toArray();
    //     });
    // }

    // /**
    //  * Get all settings grouped by topic
    //  */
    // public static function allByTopic(): array
    // {
    //     return self::where('is_visible', true)
    //         ->orderBy('topic')
    //         ->orderBy('group')
    //         ->orderBy('sort_order')
    //         ->get()
    //         ->groupBy('topic')
    //         ->map(
    //             fn($topic) => $topic->groupBy('group')
    //                 ->map(fn($group) => $group->mapWithKeys(
    //                     fn($row) => [$row->key => self::castValue($row)]
    //                 ))
    //         )
    //         ->toArray();
    // }

    // /**
    //  * Get all settings for export
    //  */
    // public static function allForExport(): array
    // {
    //     return self::orderBy('topic')
    //         ->orderBy('group')
    //         ->orderBy('sort_order')
    //         ->get()
    //         ->map(fn($row) => [
    //             'topic' => $row->topic,
    //             'group' => $row->group,
    //             'key' => $row->key,
    //             'label' => $row->label,
    //             'value' => $row->value,
    //             'default_value' => $row->default_value,
    //             'type' => $row->type,
    //             'input_type' => $row->input_type,
    //             'description' => $row->description,
    //             'help_text' => $row->help_text,
    //             'validation_rules' => $row->validation_rules,
    //             'options' => $row->options,
    //             'is_editable' => $row->iseditable,
    //             'is_visible' => $row->is_visible,
    //         ])
    //         ->toArray();
    // }

    // /**
    //  * Scope: Get only editable settings
    //  */
    // public function scopeEditable($query)
    // {
    //     return $query->where('iseditable', true);
    // }

    // /**
    //  * Scope: Get settings by type
    //  */
    // public function scopeByType($query, string $type)
    // {
    //     return $query->where('type', $type);
    // }

    // /**
    //  * Scope: Get settings by topic
    //  */
    // public function scopeByTopic($query, string $topic)
    // {
    //     return $query->where('topic', $topic);
    // }

    // /**
    //  * Scope: Get settings by group
    //  */
    // public function scopeByGroup($query, string $group)
    // {
    //     return $query->where('group', $group);
    // }

    // /**
    //  * Flush cache for single setting
    //  */
    // public static function flushCache(string $key): void
    // {
    //     Cache::forget("setting.{$key}");
    // }

    // /**
    //  * Flush cache for entire topic
    //  */
    // public static function flushTopicCache(string $topic): void
    // {
    //     Cache::forget("topic.{$topic}");
    // }

    // /**
    //  * Flush all settings cache
    //  */
    // public static function flushAllCache(): void
    // {
    //     Cache::tags(['settings'])->flush();
    // }

    // /**
    //  * Set a setting value
    //  */
    // public static function set(string $key, mixed $value, ?string $topic = null): self
    // {
    //     $setting = self::where('key', $key)->first() ?? new self(['key' => $key]);

    //     // Encode based on type
    //     if ($setting->type === 'json' || $setting->type === 'array') {
    //         $setting->value = is_string($value) ? $value : json_encode($value);
    //     } else {
    //         $setting->value = $value;
    //     }

    //     if ($topic) {
    //         $setting->topic = $topic;
    //     }

    //     $setting->updated_by = auth()->id();
    //     $setting->save();

    //     return $setting;
    // }

    // // /**
    // //  * Increment/decrement numeric setting
    // //  */
    // // public function increment(string $key, int $amount = 1): void
    // // {
    // //     $setting = self::where('key', $key)->first();
    // //     if ($setting) {
    // //         $setting->value = (int) $setting->value + $amount;
    // //         $setting->save();
    // //     }
    // // }

    // /**
    //  * Check if setting exists
    //  */
    // public static function has(string $key): bool
    // {
    //     return self::where('key', $key)->exists();
    // }

    // /**
    //  * Get or create a setting
    //  */
    // public static function ensure(
    //     string $key,
    //     mixed $value,
    //     string $topic,
    //     string $type = 'string',
    //     ?string $label = null,
    //     ?string $description = null
    // ): self {
    //     return self::firstOrCreate(
    //         ['key' => $key],
    //         [
    //             'value' => is_string($value) ? $value : json_encode($value),
    //             'default_value' => is_string($value) ? $value : json_encode($value),
    //             'type' => $type,
    //             'input_type' => $type,
    //             'topic' => $topic,
    //             'label' => $label ?? str_replace('.', ' ', $key),
    //             'description' => $description ?? str_replace('.', ' ', $key),
    //             'iseditable' => true,
    //             'is_visible' => true,
    //         ]
    //     );
    // }
}
